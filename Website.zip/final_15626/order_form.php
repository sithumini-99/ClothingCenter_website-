<?php 

  $connection = mysqli_connect('localhost','root','','order_db');

  if(!$connection)
  {
    echo"connection failed:";
  }
  else{
   echo"connected successfully";
  }


   if(isset($_POST['send'])){
      $nic= $_POST['nic'];
      $name = $_POST['name'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $code = $_POST['code'];
      $items = $_POST['items'];
      $price = $_POST['price'];
      $date = $_POST['date'];

      $request = " INSERT INTO order_form(nic, name, email, phone, address, code, items, price, date) VALUES ('$nic','$name','$email','$phone','$address','$code','$items','$price','$date') ";
      mysqli_query($connection, $request);

      header('location:order.php'); 

   }else{
      echo 'something went wrong please try again!';
   }

?>