<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- Swiper js link -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><font color="red"><b>Clothly</b></font></a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about us</a>
      <a href="collection.php">collection</a>
      <a href="order.php">order</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home">

   <div class="swiper home-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide" style="background:url(images/home.jpg) no-repeat">
            <div class="content">
               <h3>shop with us</h3>
               <span>Convenience, New Fashions , Wide Selection</span> 
               <a href="collection.php" class="btn">shop now</a>
            </div>
         </div>

         <div class="swiper-slide slide" style="background:url(images/home2.jpg) no-repeat">
            <div class="content">
               <h3>shop with us</h3>
                <span>Convenience, New Fashions , Wide Selection</span>
               <a href="collection.php" class="btn">Shop Now</a>
            </div>
         </div>
         
      </div>

      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>

   </div>

</section>

<!-- home section ends -->

<!-- services section starts  -->

<section class="services">

   <div class="box-container">

      <div class="box">
         <h3>Comprehensive selection</h3>
         <h2>shop online from your favourite department store brand</h2>
      </div>

      <div class="box">
         <h3>All-island delivery</h3>
         <h2>Delivery within 3-4 working days to Colombo and 5-7 working days island-wide</h2>
      </div>

      <div class="box">
         <h3>Top-notch support</h3>
         <h2>Get support from our team via phone,social media and email</h2>
      </div>

      <div class="box">
         <h3>Easy exchange</h3>
         <h2>Exchange from complete online</h2>
      </div>

   </div>

</section>

<!-- services section ends -->


<!-- home brands section starts  -->

<section class="home-brands">

   <h1 class="heading-title"> Exclusive Brands </h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/img-1.jpg" alt="">
         </div>    
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-2.jpg" alt="">
         </div>      
      </div>
      
      <div class="box">
         <div class="image">
            <img src="images/img-3.jpg" alt="">
         </div>
      </div>

       <div class="box">
         <div class="image">
            <img src="images/img-4.jpg" alt="">
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-5.jpg" alt="">
         </div>
      </div>

   </div>

</section>

<!-- home brands section ends -->

<!-- home offer section starts  -->

<section class="home-offer">
   <div class="content">
      <h3>upto 30% off</h3>
      <p></p>
      <a href="collection.php" class="btn">Shop now</a>
   </div>
</section>

<!-- home offer section ends -->

















<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Other</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-444-5555 </a>
         <a href="#"> <i class="fas fa-envelope"></i> clothly@gmail.com </a>
       
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

</section>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>